﻿using DaniGroup.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DaniGroup.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<CartItem> CartItems { get; set; }
        public DbSet<ContactMessage> ContactMessages { get; set; }
        public DbSet<ReturnRequest> ReturnRequests { get; set; }
        public DbSet<TowingRequest> TowingRequests { get; set; }
        public DbSet<ParcelRequest> ParcelRequests { get; set; }
        public DbSet<MovingRequest> MovingRequests { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }

        public DbSet<ProductReview> ProductReviews => Set<ProductReview>();

        public DbSet<SiteSetting> SiteSettings => Set<SiteSetting>();
    }
}