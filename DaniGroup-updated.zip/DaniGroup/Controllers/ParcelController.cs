﻿using DaniGroup.Data;
using DaniGroup.Models;
using Microsoft.AspNetCore.Mvc;

namespace DaniGroup.Controllers
{
    public class ParcelController : Controller
    {
        private readonly ApplicationDbContext _context;

        // Pricing benchmarked against SA courier rates (Courier Guy, Fastway, PostNet, Paxi):
        // small parcels ~R60-R110, medium ~R95-R135, large ~R150-R360, bulky/freight R250+.
        // Dani Group Dropper is same-city door-to-door, priced as a base fee + per-km rate.
        public static readonly List<ParcelRate> Rates = new()
        {
            new ParcelRate { SizeType = "Small", Label = "Small Parcel", WeightRange = "Up to 5 kg", BaseFee = 60m, PerKmRate = 8m, Icon = "📦" },
            new ParcelRate { SizeType = "Medium", Label = "Medium Parcel", WeightRange = "5 - 15 kg", BaseFee = 90m, PerKmRate = 10m, Icon = "📦" },
            new ParcelRate { SizeType = "Large", Label = "Large Parcel", WeightRange = "15 - 30 kg", BaseFee = 150m, PerKmRate = 12m, Icon = "🗃️" },
            new ParcelRate { SizeType = "Bulky", Label = "Bulky / Freight", WeightRange = "30 kg+", BaseFee = 250m, PerKmRate = 15m, Icon = "🚛" },
        };

        public ParcelController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Rates = Rates;
            return View(new ParcelRequest());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(ParcelRequest model)
        {
            var rate = Rates.FirstOrDefault(r => r.SizeType == model.ParcelSize);

            if (rate == null)
            {
                ModelState.AddModelError(nameof(model.ParcelSize), "Please select a valid parcel size.");
            }

            if (!ModelState.IsValid)
            {
                ViewBag.Rates = Rates;
                return View(model);
            }

            model.EstimatedCost = rate!.BaseFee + (rate.PerKmRate * (decimal)model.DistanceKm);
            model.CreatedAt = DateTime.Now;
            model.Status = "Pending";

            _context.ParcelRequests.Add(model);
            await _context.SaveChangesAsync();

            ViewBag.Success = $"Your parcel delivery request has been submitted. Estimated cost: R{model.EstimatedCost:F2}. Our team will confirm collection shortly.";
            ViewBag.Rates = Rates;

            return View(new ParcelRequest());
        }
    }

    public class ParcelRate
    {
        public string SizeType { get; set; } = string.Empty;
        public string Label { get; set; } = string.Empty;
        public string WeightRange { get; set; } = string.Empty;
        public decimal BaseFee { get; set; }
        public decimal PerKmRate { get; set; }
        public string Icon { get; set; } = string.Empty;
    }
}
