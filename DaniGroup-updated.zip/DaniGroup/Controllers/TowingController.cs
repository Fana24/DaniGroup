﻿using DaniGroup.Data;
using DaniGroup.Models;
using Microsoft.AspNetCore.Mvc;

namespace DaniGroup.Controllers
{
    public class TowingController : Controller
    {
        private readonly ApplicationDbContext _context;

        // Pricing: R450 call-out fee + per-km rate, based on vehicle type.
        public static readonly List<TowingRate> Rates = new()
        {
            new TowingRate { VehicleType = "Bike", Label = "Bike", BaseFee = 450m, PerKmRate = 15m, Icon = "🏍️" },
            new TowingRate { VehicleType = "Car", Label = "Car", BaseFee = 450m, PerKmRate = 20m, Icon = "🚗" },
            new TowingRate { VehicleType = "SUV/Bakkie", Label = "SUV / Bakkie", BaseFee = 450m, PerKmRate = 25m, Icon = "🚙" },
            new TowingRate { VehicleType = "Other", Label = "Other", BaseFee = 450m, PerKmRate = 30m, Icon = "🔧" },
        };

        public TowingController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Rates = Rates;
            return View(new TowingRequest());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(TowingRequest model)
        {
            var rate = Rates.FirstOrDefault(r => r.VehicleType == model.VehicleType);

            if (rate == null)
            {
                ModelState.AddModelError(nameof(model.VehicleType), "Please select a valid vehicle type.");
            }

            if (!ModelState.IsValid)
            {
                ViewBag.Rates = Rates;
                return View(model);
            }

            model.EstimatedCost = rate!.BaseFee + (rate.PerKmRate * (decimal)model.DistanceKm);
            model.CreatedAt = DateTime.Now;
            model.Status = "Pending";

            _context.TowingRequests.Add(model);
            await _context.SaveChangesAsync();

            ViewBag.Success = $"Your towing application has been submitted. Estimated cost: R{model.EstimatedCost:F2}. Our team will contact you shortly to confirm.";
            ViewBag.Rates = Rates;

            return View(new TowingRequest());
        }
    }

    public class TowingRate
    {
        public string VehicleType { get; set; } = string.Empty;
        public string Label { get; set; } = string.Empty;
        public decimal BaseFee { get; set; }
        public decimal PerKmRate { get; set; }
        public string Icon { get; set; } = string.Empty;
    }
}
