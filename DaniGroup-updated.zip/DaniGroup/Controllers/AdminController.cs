﻿using DaniGroup.Data;
using DaniGroup.Helpers;
using DaniGroup.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace DaniGroup.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public AdminController(ApplicationDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Products()
        {
            var products = await _context.Products
                .Include(p => p.Category)
                .OrderByDescending(p => p.Id)
                .ToListAsync();

            return View(products);
        }

        [HttpGet]
        public async Task<IActionResult> AddProduct()
        {
            await LoadCategories();
            return View(new Product());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddProduct(Product model, IFormFile? imageFile, string? newCategoryName)
        {
            await ApplyNewCategoryIfProvided(model, newCategoryName);
            await LoadCategories(model.CategoryId);

            if (model.CategoryId <= 0)
            {
                ModelState.AddModelError(nameof(model.CategoryId), "Please select a category or type a new one.");
            }

            if (!ModelState.IsValid)
            {
                TempData["ErrorMessage"] = "Please fix the form errors and try again.";
                return View(model);
            }

            if (imageFile != null)
            {
                if (!FileValidationHelper.IsValidImage(imageFile))
                {
                    ModelState.AddModelError("", "Only JPG, JPEG, PNG, or WEBP images up to 2 MB are allowed.");
                    TempData["ErrorMessage"] = "Image upload failed validation.";
                    return View(model);
                }

                string uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads", "products");
                Directory.CreateDirectory(uploadsFolder);

                string fileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                string filePath = Path.Combine(uploadsFolder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await imageFile.CopyToAsync(stream);
                }

                model.ImagePath = "/uploads/products/" + fileName;
            }

            try
            {
                _context.Products.Add(model);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Product added successfully.";
                return RedirectToAction("Products");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while saving the product: " + ex.Message);
                TempData["ErrorMessage"] = "Could not save the product.";
                return View(model);
            }
        }

        [HttpGet]
        public async Task<IActionResult> EditProduct(int id)
        {
            var product = await _context.Products.FindAsync(id);

            if (product == null)
                return NotFound();

            await LoadCategories(product.CategoryId);
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditProduct(Product model, IFormFile? imageFile, string? newCategoryName)
        {
            await ApplyNewCategoryIfProvided(model, newCategoryName);
            await LoadCategories(model.CategoryId);

            if (model.CategoryId <= 0)
            {
                ModelState.AddModelError(nameof(model.CategoryId), "Please select a category or type a new one.");
            }

            if (!ModelState.IsValid)
            {
                TempData["ErrorMessage"] = "Please fix the form errors and try again.";
                return View(model);
            }

            var product = await _context.Products.FindAsync(model.Id);

            if (product == null)
                return NotFound();

            product.Name = model.Name;
            product.Description = model.Description;
            product.Price = model.Price;
            product.StockQuantity = model.StockQuantity;
            product.CategoryId = model.CategoryId;
            product.IsFeatured = model.IsFeatured;

            if (imageFile != null)
            {
                if (!FileValidationHelper.IsValidImage(imageFile))
                {
                    ModelState.AddModelError("", "Only JPG, JPEG, PNG, or WEBP images up to 2 MB are allowed.");
                    TempData["ErrorMessage"] = "Image upload failed validation.";
                    return View(model);
                }

                string uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads", "products");
                Directory.CreateDirectory(uploadsFolder);

                string fileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                string filePath = Path.Combine(uploadsFolder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await imageFile.CopyToAsync(stream);
                }

                product.ImagePath = "/uploads/products/" + fileName;
            }

            try
            {
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Product updated successfully.";
                return RedirectToAction("Products");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while updating the product: " + ex.Message);
                TempData["ErrorMessage"] = "Could not update the product.";
                return View(model);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var product = await _context.Products
                .Include(p => p.Reviews)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (product == null)
            {
                TempData["ErrorMessage"] = "Product not found.";
                return RedirectToAction("Products");
            }

            try
            {
                var cartItems = await _context.CartItems
                    .Where(c => c.ProductId == id)
                    .ToListAsync();

                if (cartItems.Any())
                {
                    _context.CartItems.RemoveRange(cartItems);
                }

                var reviews = await _context.ProductReviews
                    .Where(r => r.ProductId == id)
                    .ToListAsync();

                if (reviews.Any())
                {
                    _context.ProductReviews.RemoveRange(reviews);
                }

                var orderItemsExist = await _context.OrderItems.AnyAsync(oi => oi.ProductId == id);
                if (orderItemsExist)
                {
                    TempData["ErrorMessage"] = "This product cannot be deleted because it exists in customer orders.";
                    return RedirectToAction("Products");
                }

                _context.Products.Remove(product);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Product deleted successfully.";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error deleting product: " + ex.Message;
            }

            return RedirectToAction("Products");
        }

        private async Task LoadCategories(int? selectedCategoryId = null)
        {
            var categories = await _context.Categories.OrderBy(c => c.Name).ToListAsync();
            ViewBag.Categories = new SelectList(categories, "Id", "Name", selectedCategoryId);
        }

        // Allows the admin to create a brand new category on the fly from the
        // Add/Edit product forms instead of being limited to the existing dropdown list.
        private async Task ApplyNewCategoryIfProvided(Product model, string? newCategoryName)
        {
            if (string.IsNullOrWhiteSpace(newCategoryName))
                return;

            var trimmedName = newCategoryName.Trim();

            var existingCategory = await _context.Categories
                .FirstOrDefaultAsync(c => c.Name.ToLower() == trimmedName.ToLower());

            if (existingCategory != null)
            {
                model.CategoryId = existingCategory.Id;
            }
            else
            {
                var category = new Category { Name = trimmedName };
                _context.Categories.Add(category);
                await _context.SaveChangesAsync();

                model.CategoryId = category.Id;
            }

            // The dropdown's bound value (often empty when a new category is being typed)
            // can leave a stale model-binding error behind, so clear it now that
            // CategoryId has been resolved to a real category.
            ModelState.Remove(nameof(model.CategoryId));
        }

        public async Task<IActionResult> Orders()
        {
            var orders = await _context.Orders
                .OrderByDescending(o => o.CreatedAt)
                .ToListAsync();

            return View(orders);
        }

        public async Task<IActionResult> OrderDetails(int id)
        {
            var order = await _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o => o.Id == id);

            if (order == null)
                return NotFound();

            return View(order);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateOrderStatus(int orderId, string orderStatus)
        {
            var order = await _context.Orders.FindAsync(orderId);

            if (order == null)
                return NotFound();

            order.OrderStatus = orderStatus;
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Order status updated successfully.";
            return RedirectToAction("OrderDetails", new { id = orderId });
        }

        // Lets the admin cancel any customer's order without deleting its history.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CancelOrder(int orderId, string? returnUrl)
        {
            var order = await _context.Orders.FindAsync(orderId);

            if (order == null)
            {
                TempData["ErrorMessage"] = "Order not found.";
                return RedirectToAction("Orders");
            }

            if (order.OrderStatus == "Cancelled")
            {
                TempData["ErrorMessage"] = $"Order #{order.Id} is already cancelled.";
            }
            else
            {
                order.OrderStatus = "Cancelled";
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"Order #{order.Id} has been cancelled.";
            }

            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            return RedirectToAction("OrderDetails", new { id = orderId });
        }

        // Lets the admin permanently remove an order (and its line items) from the system.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteOrder(int id)
        {
            var order = await _context.Orders
                .Include(o => o.OrderItems)
                .FirstOrDefaultAsync(o => o.Id == id);

            if (order == null)
            {
                TempData["ErrorMessage"] = "Order not found.";
                return RedirectToAction("Orders");
            }

            try
            {
                if (order.OrderItems.Any())
                {
                    _context.OrderItems.RemoveRange(order.OrderItems);
                }

                _context.Orders.Remove(order);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = $"Order #{id} has been permanently removed.";
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "Error removing order: " + ex.Message;
            }

            return RedirectToAction("Orders");
        }

        public async Task<IActionResult> Returns()
        {
            var returnsList = await _context.ReturnRequests
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();

            return View(returnsList);
        }

        public async Task<IActionResult> Messages()
        {
            var messages = await _context.ContactMessages
                .OrderByDescending(m => m.CreatedAt)
                .ToListAsync();

            return View(messages);
        }
    }
}