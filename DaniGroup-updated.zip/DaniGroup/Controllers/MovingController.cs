﻿using DaniGroup.Data;
using DaniGroup.Models;
using Microsoft.AspNetCore.Mvc;

namespace DaniGroup.Controllers
{
    public class MovingController : Controller
    {
        private readonly ApplicationDbContext _context;

        // Pricing benchmarked against SA removal companies (Handyman JHB, Trucks4Hire, Biggles):
        // bakkie/van hire ~R70-R250/hr or R300-R800/day, 1-2 ton trucks ~R750-R1,200/day,
        // 4-8 ton trucks ~R1,500-R3,000/day. Dani Group Dropper includes driver + loading help,
        // billed as a call-out fee + hourly on-site rate (with a minimum) + per-km travel rate.
        public static readonly List<MovingRate> Rates = new()
        {
            new MovingRate { VehicleType = "MiniVan", Label = "Mini Van", BestFor = "A few boxes or a single item", CalloutFee = 550m, HourlyRate = 120m, MinHours = 2, PerKmRate = 7m, Icon = "🚐" },
            new MovingRate { VehicleType = "Bakkie1Ton", Label = "1 Ton Bakkie", BestFor = "Bachelor flat or studio move", CalloutFee = 650m, HourlyRate = 180m, MinHours = 2, PerKmRate = 9m, Icon = "🛻" },
            new MovingRate { VehicleType = "Truck4Ton", Label = "4 Ton Truck", BestFor = "2-3 bedroom home", CalloutFee = 900m, HourlyRate = 280m, MinHours = 3, PerKmRate = 12m, Icon = "🚚" },
            new MovingRate { VehicleType = "Truck8Ton", Label = "8 Ton Truck", BestFor = "Large home or office move", CalloutFee = 1300m, HourlyRate = 420m, MinHours = 3, PerKmRate = 16m, Icon = "🚛" },
        };

        public MovingController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Rates = Rates;
            return View(new MovingRequest());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(MovingRequest model)
        {
            var rate = Rates.FirstOrDefault(r => r.VehicleType == model.VehicleType);

            if (rate == null)
            {
                ModelState.AddModelError(nameof(model.VehicleType), "Please select a valid vehicle type.");
            }

            if (!ModelState.IsValid)
            {
                ViewBag.Rates = Rates;
                return View(model);
            }

            var billedHours = Math.Max(model.EstimatedHours, rate!.MinHours);
            model.EstimatedCost = rate.CalloutFee
                + (rate.HourlyRate * (decimal)billedHours)
                + (rate.PerKmRate * (decimal)model.DistanceKm);
            model.CreatedAt = DateTime.Now;
            model.Status = "Pending";

            _context.MovingRequests.Add(model);
            await _context.SaveChangesAsync();

            ViewBag.Success = $"Your furniture moving request has been submitted. Estimated cost: R{model.EstimatedCost:F2} (min {rate.MinHours}hr on-site). Our team will confirm your booking shortly.";
            ViewBag.Rates = Rates;

            return View(new MovingRequest());
        }
    }

    public class MovingRate
    {
        public string VehicleType { get; set; } = string.Empty;
        public string Label { get; set; } = string.Empty;
        public string BestFor { get; set; } = string.Empty;
        public decimal CalloutFee { get; set; }
        public decimal HourlyRate { get; set; }
        public double MinHours { get; set; }
        public decimal PerKmRate { get; set; }
        public string Icon { get; set; } = string.Empty;
    }
}
