﻿using System.ComponentModel.DataAnnotations;

namespace DaniGroup.Models
{
    public class MovingRequest
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [Phone]
        [StringLength(30)]
        public string Phone { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [StringLength(30)]
        [Display(Name = "Vehicle Type")]
        public string VehicleType { get; set; }

        [Required]
        [StringLength(250)]
        [Display(Name = "Pickup Location")]
        public string PickupLocation { get; set; }

        [Required]
        [StringLength(250)]
        [Display(Name = "Drop-off Location")]
        public string DropoffLocation { get; set; }

        [Range(0, 2000, ErrorMessage = "Enter a realistic distance in km.")]
        [Display(Name = "Distance (km)")]
        public double DistanceKm { get; set; }

        [Range(0, 48, ErrorMessage = "Enter a realistic number of hours.")]
        [Display(Name = "Estimated Hours On-Site")]
        public double EstimatedHours { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Preferred Moving Date")]
        public DateTime? PreferredDate { get; set; }

        [DataType(DataType.Currency)]
        [Display(Name = "Estimated Cost")]
        public decimal EstimatedCost { get; set; }

        [StringLength(1000)]
        [Display(Name = "Additional Notes")]
        public string? Notes { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public string Status { get; set; } = "Pending";
    }
}
