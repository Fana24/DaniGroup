<?php
require_once __DIR__ . '/includes/bootstrap.php';

$stmt = db()->query(
    'SELECT p.*, c.name AS category_name FROM products p
     LEFT JOIN categories c ON c.id = p.category_id
     WHERE p.is_featured = 1
     ORDER BY p.id DESC
     LIMIT 6'
);
$featuredProducts = $stmt->fetchAll();

$pageTitle = SITE_NAME . ' - Auto Parts, Accessories & Delivery Services';
require __DIR__ . '/includes/header.php';
?>

<section class="hero-section">
    <div class="hero-overlay">
        <div class="hero-content text-center">
            <span class="badge-dani mb-3 d-inline-block">Trusted Automotive &amp; Service Platform</span>
            <h1>Dani Group</h1>
            <p>
                Your trusted destination for premium car parts, appliances, accessories, bike parts,
                parcel delivery, towing, furniture moving, and reliable customer support.
            </p>
            <div class="mt-4">
                <a href="/products.php" class="btn btn-dani-primary btn-lg me-2 mb-2">Shop Now</a>
                <a href="/dropper.php" class="btn btn-dani-outline btn-lg mb-2">Explore Services</a>
            </div>
        </div>
    </div>
</section>

<section class="text-center my-5">
    <img src="/assets/images/logo/DA Logo.png" alt="Dani Group Logo" style="max-height: 150px;" class="mb-3">
    <h2 class="section-title">Performance. Reliability. Service.</h2>
    <p class="text-muted-custom">
        Dani Group brings together automotive retail and practical customer services in one powerful platform.
    </p>
</section>

<section class="my-5">
    <div class="row g-4">
        <div class="col-md-4">
            <div class="category-box">
                <h3>Car Parts</h3>
                <p>High-quality parts for repairs, upgrades, and long-term performance.</p>
                <a href="/products.php" class="btn btn-dani-outline mt-2">Browse Parts</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="category-box">
                <h3>Accessories</h3>
                <p>Modern interior and exterior accessories built for style and convenience.</p>
                <a href="/products.php" class="btn btn-dani-outline mt-2">Browse Accessories</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="category-box">
                <h3>Bike Parts</h3>
                <p>Strong, reliable bike components and maintenance essentials.</p>
                <a href="/products.php" class="btn btn-dani-outline mt-2">Browse Bike Parts</a>
            </div>
        </div>
    </div>
</section>

<section class="my-5">
    <div class="page-banner text-center">
        <h2 class="section-title">Dropper Services</h2>
        <p class="text-muted-custom mb-0">
            From parcel delivery to 24-hour towing, Dani Group helps keep your day moving.
        </p>
    </div>

    <div class="row g-4">
        <div class="col-md-3">
            <div class="dashboard-card">
                <h4>Send Parcels</h4>
                <p>Secure parcel movement with fast service options.</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="dashboard-card">
                <h4>Move Furniture</h4>
                <p>Convenient furniture transport for home and office needs.</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="dashboard-card">
                <h4>24hr Towing</h4>
                <p>Round-the-clock towing support when you need it most.</p>
            </div>
        </div>
        <div class="col-md-3">
            <div class="dashboard-card">
                <h4>Become a Driver</h4>
                <p>Join Dani Group and grow with our service network.</p>
            </div>
        </div>
    </div>
</section>

<section class="mt-5">
    <div class="page-banner text-center">
        <h2 class="section-title">Featured Products</h2>
        <p class="text-muted-custom mb-0">Selected products from our latest collection</p>
    </div>

    <div class="row">
        <?php foreach ($featuredProducts as $product): ?>
            <div class="col-md-4 mb-4">
                <div class="card dani-card h-100">
                    <?php if (!empty($product['image_path'])): ?>
                        <img src="<?= e($product['image_path']) ?>" class="card-img-top product-image" alt="<?= e($product['name']) ?>">
                    <?php endif; ?>
                    <div class="card-body d-flex flex-column">
                        <h5><?= e($product['name']) ?></h5>
                        <p class="flex-grow-1"><?= e($product['description']) ?></p>
                        <p class="product-price"><strong><?= money($product['price']) ?></strong></p>
                        <a href="/product-details.php?id=<?= (int) $product['id'] ?>" class="btn btn-dani-primary">View Product</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
