<?php
/**
 * Central configuration for the Dani Group PHP site.
 *
 * IMPORTANT: Fill in the database and Yoco values below before you upload
 * this to your cPanel hosting. See DEPLOY-README.md for step-by-step
 * instructions on creating the database in cPanel.
 */

// ---------------------------------------------------------------------
// Database connection (cPanel: MySQL Databases -> create DB + user)
// cPanel usually prefixes both the database name and the DB user with
// your cPanel username, e.g. "myuser_danigroup" and "myuser_dbuser".
// ---------------------------------------------------------------------
define('DB_HOST', 'localhost');
define('DB_NAME', 'cpaneluser_danigroup');
define('DB_USER', 'cpaneluser_dbuser');
define('DB_PASS', 'CHANGE_ME');
define('DB_CHARSET', 'utf8mb4');

// ---------------------------------------------------------------------
// Site basics
// ---------------------------------------------------------------------
define('SITE_NAME', 'Dani Group');
define('CURRENCY_PREFIX', 'R '); // South African Rand
define('SITE_TIMEZONE', 'Africa/Johannesburg');

// Base URL of the site, no trailing slash. Used for absolute links in
// emails and for building Yoco success/cancel redirect URLs.
define('SITE_BASE_URL', 'https://www.danigroup.co.za');

// ---------------------------------------------------------------------
// File uploads
// ---------------------------------------------------------------------
define('UPLOAD_MAX_BYTES', 2 * 1024 * 1024); // 2 MB, same limit as the original app
define('UPLOAD_ALLOWED_EXT', ['jpg', 'jpeg', 'png', 'webp']);
define('UPLOAD_ALLOWED_MIME', ['image/jpeg', 'image/png', 'image/webp']);

// ---------------------------------------------------------------------
// Yoco payment gateway
// Get these from your Yoco merchant portal (https://portal.yoco.com).
// IMPORTANT: exactly like the original ASP.NET Core app, the Yoco
// checkout payload/response field names and the webhook signature
// scheme should be double-checked against the current Yoco API docs
// for your account before going live with real payments.
// ---------------------------------------------------------------------
define('YOCO_SECRET_KEY', 'sk_test_xxxxxxxxxxxxxxxxxxxx');
define('YOCO_WEBHOOK_SECRET', 'whsec_xxxxxxxxxxxxxxxxxxxx');
define('YOCO_API_BASE_URL', 'https://payments.yoco.com/api');

// ---------------------------------------------------------------------
// Outgoing email (contact form confirmations, order notices, etc.)
// PHP's built-in mail() uses the server's local sendmail/exim on
// cPanel, which normally works out of the box for a cPanel-hosted
// domain without any extra setup.
// ---------------------------------------------------------------------
define('MAIL_FROM_ADDRESS', 'no-reply@danigroup.co.za');
define('MAIL_FROM_NAME', 'Dani Group');

// ---------------------------------------------------------------------
// Error display - turn OFF once the site is live on cPanel.
// ---------------------------------------------------------------------
define('APP_DEBUG', true);

if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}

date_default_timezone_set(SITE_TIMEZONE);
